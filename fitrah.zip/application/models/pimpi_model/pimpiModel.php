<?php
class PimpiModel extends CI_Model{
	public function _construct(){
	parent::_construct();
	}
}
?>