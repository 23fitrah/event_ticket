<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" lang="">
<head>
			<meta name="keywords" content=" " />
			<meta name="description" content=" " />
			<meta charset="utf-8" />
			<link rel="stylesheet" href="style.css: " />
			<script type="text/javascript" src="<?php echo base_url('asset/bootstrap/js/bootstrap.js');?>"></script>
			<link href="<?php echo base_url();?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
			<link href="<?php echo base_url();?>assets/css/style-form.css" rel="stylesheet">
			<style type="text/css">
			.background1{background-color:orange;background-size:7% 7%;background-image:url('<?php echo base_url(); ?>images/faviconpimpi.png');background-repeat:repeat}
			</style>
<title>Formulir Seminar PIMPI</title>
</head>
<body class="background1 ">
<div class="garis margin ">
<div class="form">
<br />
<div class="title background2">
<br />
<div style="font-size:18pt"><b>Pendaftaran Seminar Nasional</b></div>
<div style="font-size:25pt"><b>Pekan Inovasi Mahasiswa Pertanian Indonesia 2014</b></div>
<div style="font-size:18pt"><b>Tema</b></div><br />
<div class="header" align="center">
<img src="<?php echo base_url(); ?>images/pimpi5.jpg" width="115pt" height="85pt" /> <img src="<?php echo base_url(); ?>images/kampus hijau.jpg" width="115pt" height="85pt" /> <img src="<?php echo base_url(); ?>images/pimpi4.jpg" width="115pt" height="85pt" /> <img src="<?php echo base_url(); ?>images/pimpi6.jpg" width="115pt" height="85pt" /> <img src="<?php echo base_url(); ?>images/pimpi1.jpg" width="115pt" height="85pt" /> <img src="<?php echo base_url(); ?>images/pimpi3.jpg" width="115pt" height="85pt" /> 
</div>
<br />
</div>
<br />
<div class="line" ></div>
<table width="100%" border="0">
<tr height="40px"><td colspan="3"> <div class="require">*) required </div></td> </tr>
<?php echo form_open('form/registration');?>
<tr height="40px"><td width="37%">Nama Lengkap<em class="require">*</em></td><td>  <?php echo form_input('nama');?><?php echo form_error('nama', '<div style="color:red">','</div>');?></td><td></td></tr>
<tr height="40px"><td width="37%">NIM/NRP Mahasiswa</td><td>  <?php echo form_input('nim/nrp');?></td><td></td></tr>
<tr height="40px"><td>No Handphone<em class="require">*</em></td><td> <?php echo form_input('no_hp');?> <?php echo form_error('no_hp', '<div style="color:red">','</div>');?></td><td></td></tr>
<tr height="40px"><td>Email<em class="require">*</em></td><td>  <?php echo form_input('email');?> <?php echo form_error('email', '<div style="color:red">','</div>');?></td><td></td></tr>
<tr height="40px"><td>Status Pendidikan<em class="require">*</em></td><td> <?php $option=array(
                     '-'=>"Pilih Pendidikan",
                     'sma'=>"SMA",
                     'mahasiswa'=>"Mahasiswa",
                     'umum'=>'Umum'
                     );
        echo form_dropdown('pendidikan',$option,'-'); ?> <?php echo form_error('pendidikan', '<div style="color:red">','</div>');?>
   </td><td></td></tr>
<tr height="40px"><td>Asal Universitas/SMA<td> <?php echo form_input('univ');?></td><td></td></tr>
<tr height="40px"><td>Untuk Mahasiswa pilih tingkatan anda</td><td>  <?php
        echo form_radio('tingkatan','S0').'S0 ';
		echo form_radio('tingkatan','S1').'S1 ';
        echo form_radio('tingkatan','S2').'S2';
   ?> </td><td></td></tr>
 <tr height="40px"><td>Harapan PIMPI untuk Tahun Depan <em class="require">*</em></td><td><?php $harapan=array(
                        'name'=>'harapan',
                        'id'=>'harapan',
                        'maxlength'=>'1000',
                        'size'=>'60'
                        );
       echo form_textarea($harapan); ?> <?php echo form_error('harapan', '<div style="color:red">','</div>');?></td><td></td></tr>
	   <tr height="40px"><td></td><td>   <?php echo form_submit('kirim','Daftar');?></td><td></td></tr>
<?php echo form_close(); ?>
</table>
<br />
<div class="line" ></div>
<br />

<div id="sidebar_left">
<div class="header_bar">Organized by</div>
<img src="<?php echo base_url(); ?>images/Forces Logo.png" width="40%" height="30%" /> <img src="<?php echo base_url(); ?>images/Logo_IPB.jpeg.png" width="30%" height="30%" /> <br />
<img src="<?php echo base_url(); ?>images/header Forces.jpg" width="40%" height="30%" /> <img src="<?php echo base_url(); ?>images/PIMPI2013.png" width="40%" height="30%" />
<br />
</div>
<div id="center">
<div class="header_bar">Sponsored by</div>
</div>
<div id="sidebar_right">
<div class="header_bar">Media Partner</div>
<img src="<?php echo base_url(); ?>images/gizi.jpg" width="30%" height="20%" /> <img src="<?php echo base_url(); ?>images/miti.jpg" width="40%" height="40%" />
<br /><img src="<?php echo base_url(); ?>images/radar.jpg" width="75%" height="30%" />
</div>
<br /><br /><br /><br /><br />
<div id="footer">
	<br />
	<div class="line" ></div>
 <div style="font-size:9pt">Copyright &copy; 2014 Scientist of Forces. All rights reserved </div>
</div>
</div>
</div>
</body>
</html>