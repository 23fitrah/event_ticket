<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" lang="">
<head>
			<meta name="keywords" content=" " />
			<meta name="description" content=" " />
			<meta charset="utf-8" />
			<link rel="stylesheet" href="style.css: " />
			<script type="text/javascript" src="<?php echo base_url('asset/bootstrap/js/bootstrap.js');?>"></script>
			<link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
			<link href="<?php echo base_url();?>assets/css/style-confirm.css" rel="stylesheet">
			<style type="text/css">
			.background1{background-color:orange;background-size:7% 7%;background-image:url('<?php echo base_url(); ?>images/faviconpimpi.png');background-repeat:repeat}
			.confirm-background1{background-color:orange;background-size:7% 20%;background-image:url('<?php echo base_url(); ?>images/faviconpimpi.png');background-repeat:repeat}	
			</style>
<title>Formulir Seminar PIMPI</title>
</head>
<body class="confirm-background1">
<div class="garis confirm-margin">
<div class="form">
<br />
<br />
<div class="confirm-title background2">
<p class="confirm-title"><b>Terimakasih <?php echo $nama; ?>,<br /> data anda telah kami rekam </b>
<p class="body">
blabla
</p>
<div class="site">Klik <a href="<?php echo site_url('form'); ?>">disini</a> untuk daftar lagi</div>
</p>
</div>
<br />

<br /><br /><br /><br /><br />
<div id="confirm-footer">
	<br />
	<div class="line" ></div>
	<div>Copyright &copy; 2014 Scientist of Forces. All rights reserved </div>
</div>
</div>
</div>
</body>
</html>