<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="<?php echo base_url ()?>assets/css/style.css">
	
</head>
<body>

<?php $this->load->view('data') ?>

</body>
</html>